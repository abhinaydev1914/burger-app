import React from 'react';
import './App.css';
import Burger from './components/Burger';

function App() {
  return (
    <div className="burgerContent">
      <Burger />
    </div>
  );
}

export default App;
